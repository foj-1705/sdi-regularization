# code was adapted from: https://github.com/csdongxian/AWP

from __future__ import print_function
import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torch.optim as optim
from torchvision import datasets, transforms
from torch.autograd import Variable

from wideresnet import *
from resnet import *
#from snart import lrat_loss
from trades_awp import *

#from at_awp import*
from perturbation import *

import numpy as np
import time

os.environ["CUDA_VISIBLE_DEVICES"]="0"

parser = argparse.ArgumentParser(description='Loss Ratio Adversarial Training')
parser.add_argument('--batch-size', type=int, default=128, metavar='N',
                    help='input batch size for training (default: 128)')
parser.add_argument('--test-batch-size', type=int, default=128, metavar='N',
                    help='input batch size for testing (default: 100)')
parser.add_argument('--epochs', type=int, default=105, metavar='N',
                    help='number of epochs to train')
parser.add_argument('--weight-decay', '--wd', default=5e-4,
                    type=float, metavar='W')
parser.add_argument('--lr', type=float, default=0.1, metavar='LR',
                    help='learning rate')
parser.add_argument('--momentum', type=float, default=0.9, metavar='M',
                    help='SGD momentum')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='disables CUDA training')
parser.add_argument('--epsilon', default=0.031,
                    help='perturbation')
parser.add_argument('--num-steps', default=10,
                    help='perturb number of steps')
parser.add_argument('--step-size', default=0.007,
                    help='perturb step size')
parser.add_argument('--beta', default=6.0,
                    help='weight before kl (misclassified examples)')

parser.add_argument('--training_version', default='lrat',
                    help = 'select lrat or lrllat')


parser.add_argument('--seed', type=int, default=7, metavar='S',
                    help='random seed (default: 900)')
parser.add_argument('--log-interval', type=int, default=100, metavar='N',
                    help='how many batches to wait before logging training status')
parser.add_argument('--model', default='wideresnet',
                    help='directory of model for saving checkpoint')
parser.add_argument('--save-freq', '-s', default=39, type=int, metavar='N',
                    help='save frequency')

parser.add_argument('--awp-gamma', default=0.005, type=float,
                    help='whether or not to add parametric noise')
parser.add_argument('--awp-warmup', default=10, type=int,
                    help='We could apply AWP after some epochs for accelerating.')

parser.add_argument('--flag', default=False, type=bool,
                    help='flag for awp reweight')


args = parser.parse_args()

if args.awp_gamma <= 0.0:
    args.awp_warmup = np.infty

# settings
model_dir = args.model
if not os.path.exists(model_dir):
    os.makedirs(model_dir)
    
log_dir = './log'
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
    
use_cuda = not args.no_cuda and torch.cuda.is_available()
torch.manual_seed(args.seed)
device = torch.device("cuda" if use_cuda else "cpu")
kwargs = {'num_workers': 10, 'pin_memory': True} if use_cuda else {}
torch.backends.cudnn.benchmark = True

# setup data loader
transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
])
transform_test = transforms.Compose([
    transforms.ToTensor(),
])
trainset = torchvision.datasets.CIFAR10(root='../data_attack/', train=True, download=True, transform=transform_train)
train_loader = torch.utils.data.DataLoader(trainset, batch_size=args.batch_size, shuffle=True, num_workers=10)
testset = torchvision.datasets.CIFAR10(root='../data_attack/', train=False, download=True, transform=transform_test)
test_loader = torch.utils.data.DataLoader(testset, batch_size=args.test_batch_size, shuffle=False, num_workers=10)


def train(args, model, device, train_loader, optimizer, epoch, awp_adversary):

    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)

        #if epoch <=80:
        
        x_adv = perturb_example(model=model, x_natural=data, y=target, step_size = args.step_size,
                                   epsilon = args.epsilon, perturb_steps=args.num_steps)
        #else:
        #   x_adv = perturb_example_wei(model=model, x_natural=data, y=target, step_size = args.step_size,
        #                           epsilon = args.epsilon, perturb_steps=args.num_steps)


        #optimizer.zero_grad()
        
        model.train()
        # calculate adversarial weight perturbation

       

            

        if epoch >= args.awp_warmup:
            awp = awp_adversary.calc_awp(inputs_adv=x_adv,
                                         inputs_clean=data,
                                         targets=target,
                                         beta=args.beta)
            awp_adversary.perturb(awp)

        optimizer.zero_grad()
        
                
        
        
        """
        logits = model(data)
        logits_adv = model(x_adv)
        prob = F.softmax(logits, dim=1)
        probs_a = F.softmax(logits_adv, dim=1)

        true_probs = torch.gather(prob, 1, (target.unsqueeze(1)).long()).squeeze()

        divg = torch.sum(kl(torch.log(probs_a + 1e-12), prob), dim =1)

        reweight =  8. * torch.exp(-3. * true_probs) * divg + 1.7
        reweight = reweight.detach()
        """

        loss_robust = F.kl_div(F.log_softmax(model(x_adv), dim=1),
                               F.softmax(model(data), dim=1),
                               reduction='batchmean')
        # calculate natural loss and backprop
        logits = model(data)
        loss_natural = F.cross_entropy(logits, target)
        #loss = loss_natural + 6.0 * loss_robust

        logits_adv = model(x_adv)

        loss  =  loss_natural + 5.*loss_robust - min_variance_loss(logits_adv, target)

        #loss = F.cross_entropy(logits_adv, target) - 3.*min_variance_loss(logits_adv, target)


        #else:
        
        #   loss = loss_nat + 5.0*(loss_kl*reweight).mean()       #+ 0.5*(loss_adv / loss_nat) + mse_loss(logit_adv, logit_nat)        

        #loss = loss.mean()

        # calculate robust loss
        #loss = lrat_loss(model=model,
        #                   x_natural=data,
        #                   y=target,
        #                   optimizer=optimizer,
        #                   training_version=args.training_version,
        #                   step_size=args.step_size,
        #                   epsilon=args.epsilon,
        #                   perturb_steps=args.num_steps,
        #                   beta=args.beta)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        if epoch >= args.awp_warmup:
                awp_adversary.restore(awp)

        # print progress
        if batch_idx % args.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx * len(data), len(train_loader.dataset),
                       100. * batch_idx / len(train_loader), loss.item()))

def adjust_learning_rate(optimizer, epoch):
    
    lr = args.lr
    if epoch >= 100:
        lr = args.lr * 0.001
    elif epoch >= 90:
        lr = args.lr * 0.01
    elif epoch >= 80:
        #flag =  True       #remove
        lr = args.lr * 0.1
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

"""

def burning_period(flag, epoch):

    if  epoch <=76:
        flag = args.flag
    else:
       flag = True
    return flag
"""



        
def _pgd_whitebox(model,
                  X,
                  y,
                  epsilon=args.epsilon,
                  num_steps=20,
                  step_size=args.epsilon/10.0):
    out = model(X)
    err = (out.data.max(1)[1] != y.data).float().sum()
    X_pgd = Variable(X.data, requires_grad=True)

    random_noise = torch.FloatTensor(*X_pgd.shape).uniform_(-epsilon, epsilon).to(device)
    X_pgd = Variable(X_pgd.data + random_noise, requires_grad=True)

    for _ in range(num_steps):
        opt = optim.SGD([X_pgd], lr=1e-3)
        opt.zero_grad()

        with torch.enable_grad():
            loss = nn.CrossEntropyLoss()(model(X_pgd), y)
        loss.backward()
        eta = step_size * X_pgd.grad.data.sign()
        X_pgd = Variable(X_pgd.data + eta, requires_grad=True)
        eta = torch.clamp(X_pgd.data - X.data, -epsilon, epsilon)
        X_pgd = Variable(X.data + eta, requires_grad=True)
        X_pgd = Variable(torch.clamp(X_pgd, 0, 1.0), requires_grad=True)
    err_pgd = (model(X_pgd).data.max(1)[1] != y.data).float().sum()
    return err, err_pgd

def eval_adv_test_whitebox(model, device, test_loader):

    model.eval()
    robust_err_total = 0
    natural_err_total = 0

    for data, target in test_loader:
        data, target = data.to(device), target.to(device)
        # pgd attack
        X, y = Variable(data, requires_grad=True), Variable(target)
        err_natural, err_robust = _pgd_whitebox(model, X, y)
        robust_err_total += err_robust
        natural_err_total += err_natural
    print('natural_acc: ', 1 - natural_err_total / len(test_loader.dataset))
    print('robust_acc: ', 1- robust_err_total / len(test_loader.dataset))
    return 1 - natural_err_total / len(test_loader.dataset), 1- robust_err_total / len(test_loader.dataset)


def main():

    model =  WideResNet().to(device)
    proxy =  WideResNet().to(device)

    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)

    proxy_optimizer = optim.SGD(proxy.parameters(), lr=args.lr)
    
    awp_adversary = TradesAWP(model=model, proxy=proxy, proxy_optim=proxy_optimizer, gamma=args.awp_gamma)
   
    
    natural_acc = []
    robust_acc = []

    rob_acc = 0.50
    
    for epoch in range(1, args.epochs + 1):
        # adjust learning rate for SGD
        adjust_learning_rate(optimizer, epoch)
        
        start_time = time.time()

        # adversarial training
        train(args, model, device, train_loader, optimizer, epoch, awp_adversary)


        print('================================================================')

        natural_err_total, robust_err_total = eval_adv_test_whitebox(model, device, test_loader)

        print('using time:', time.time()-start_time)
        
        natural_acc.append(natural_err_total)
        robust_acc.append(robust_err_total)
        print('================================================================')
        
        if  robust_err_total > rob_acc:
           rob_acc = robust_err_total
           torch.save(model.state_dict(), '../paper/trades5-awp-1std-marg-loss-0005epoch.pt')
        
        #file_name = os.path.join(log_dir, 'train_stats.npy')
        #np.save(file_name, np.stack((np.array(natural_acc), np.array(robust_acc))))        

        # save checkpoint
        if epoch % args.save_freq == 0:
            torch.save(model.state_dict(),
                       os.path.join(model_dir, 'model-res-epoch{}.pt'.format(epoch)))
            torch.save(optimizer.state_dict(),
                       os.path.join(model_dir, 'opt-res-checkpoint_epoch{}.tar'.format(epoch)))


if __name__ == '__main__':
    main()
