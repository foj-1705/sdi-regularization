# This is a simple implementation of AWP for Standard Adversarial Training (Madry)
import copy
import torch.nn as nn
import torch.optim as optim
import torch
EPS = 1E-20


def normalize(perturbations, weights):
    perturbations.mul_(weights.norm()/(perturbations.norm() + EPS))


def normalize_grad_by_weights(weights, ref_weights):
    for w, ref_w in zip(weights, ref_weights):
        if w.dim() <= 1:
            w.grad.data.fill_(0)  # ignore perturbations with 1 dimension (e.g. BN, bias)
        else:

            normalize(w.grad.data, ref_w)




def step_pos(x):
    return torch.where(x >= 0.0, torch.tensor(1), torch.tensor(0))





def PM(logit, target):
    eye = torch.eye(10).cuda()
    probs_GT = (logit.softmax(1) * eye[target]).sum(1).detach()
    top2_probs = logit.softmax(1).topk(2, largest = True)
    GT_in_top2_ind = (top2_probs[1] == target.view(-1,1)).float().sum(1) == 1
    probs_2nd = torch.where(GT_in_top2_ind, top2_probs[0].sum(1) - probs_GT, top2_probs[0][:,0]).detach()
    margin = probs_GT - probs_2nd
    return margin




import torch.nn.functional as F



def min_variance_loss(logits, label):
    
    direc = step_pos(PM(logits, label)).detach()
    #print(direc.item())
    logits_ =  logits.softmax(1)
    
    eye = torch.eye(logits_.shape[1]).cuda()
    
    logits_y = (logits_ * eye[label.data]).sum(1)
    
    logits_y = logits_y.view(-1, 1)
    
    diff =   logits_ -  logits_y  #torch.mean(logits_, dim=1)            #logits_y 
    
    #trad_std =  torch.std(logits_)
    
    var  = (torch.sum(torch.square(diff), dim=1)) /(logits_.shape[1] - 1)
    
    std =  torch.sqrt(var)
    
    std_loss =  direc*std  #torch.clamp(std, min=-0.1)                         #std  #F.relu(std)

    return  std_loss.mean() 






class AdvWeightPerturb(object):
    """
    This is an implementation of AWP ONLY for Standard adversarial training
    """
    def __init__(self, model, eta, nb_iter=1):
        super(AdvWeightPerturb, self).__init__()
        self.eta = eta
        self.nb_iter = nb_iter
        self.model = model
        self.optim = optim.SGD(model.parameters(), lr=eta/nb_iter)
        self.criterion = nn.CrossEntropyLoss()
        self.diff = None

    def perturb(self, X_adv, y):
        # store the original weight
        old_w = copy.deepcopy([p.data for p in self.model.parameters()])

        # perturb the model
        for idx in range(self.nb_iter):
            self.optim.zero_grad()
            outputs = self.model(X_adv)
            loss = - self.criterion(outputs, y) +  min_variance_loss(outputs, y)
            loss.backward()

            # normalize the gradient
            normalize_grad_by_weights(self.model.parameters(), old_w)

            self.optim.step()

        # calculate the weight perturbation
        self.diff = [w1 - w2 for w1, w2 in zip(self.model.parameters(), old_w)]

    def restore(self):
        for w, v in zip(self.model.parameters(), self.diff):
            w.data.sub_(v.data)
