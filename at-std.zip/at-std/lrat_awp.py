import torch
from collections import OrderedDict
import torch.nn as nn
import torch.nn.functional as F
EPS = 1E-20


def diff_in_weights(model, proxy):
    diff_dict = OrderedDict()
    model_state_dict = model.state_dict()
    proxy_state_dict = proxy.state_dict()
    for (old_k, old_w), (new_k, new_w) in zip(model_state_dict.items(), proxy_state_dict.items()):
        if len(old_w.size()) <= 1:
            continue
        if 'weight' in old_k:
            diff_w = new_w - old_w
            diff_dict[old_k] = old_w.norm() / (diff_w.norm() + EPS) * diff_w
    return diff_dict


def add_into_weights(model, diff, coeff=1.0):
    names_in_diff = diff.keys()
    with torch.no_grad():
        for name, param in model.named_parameters():
            if name in names_in_diff:
                param.add_(coeff * diff[name])




def step_pos(x):
    return torch.where(x >= 0.0, torch.tensor(1), torch.tensor(0))

def PM(logit, target):
    eye = torch.eye(10).cuda()
    probs_GT = (logit.softmax(1) * eye[target]).sum(1).detach()
    top2_probs = logit.softmax(1).topk(2, largest = True)
    GT_in_top2_ind = (top2_probs[1] == target.view(-1,1)).float().sum(1) == 1
    probs_2nd = torch.where(GT_in_top2_ind, top2_probs[0].sum(1) - probs_GT, top2_probs[0][:,0]).detach()
    margin = probs_GT - probs_2nd
    return margin


import torch.nn.functional as F

def min_variance_loss(logits, label):
    
    direc = step_pos(PM(logits, label)).detach()
    #print(direc.item())
    logits_ =  logits.softmax(1)
    
    eye = torch.eye(logits_.shape[1]).cuda()
    
    logits_y = (logits_ * eye[label.data]).sum(1)
    
    logits_y = logits_y.view(-1, 1)
    
    diff =   logits_ -  logits_y  #torch.mean(logits_, dim=1)            #logits_y 
    
    #trad_std =  torch.std(logits_)
    
    var  = (torch.sum(torch.square(diff), dim=1)) /(logits_.shape[1] - 1)
    
    std =  torch.sqrt(var)
    
    std_loss =  direc*std  #torch.clamp(std, min=-0.1)                         #std  #F.relu(std)

    return  std_loss.mean()









class TradesAWP(object):
    def __init__(self, model, proxy, proxy_optim, gamma):
        super(TradesAWP, self).__init__()
        self.model = model
        self.proxy = proxy
        self.proxy_optim = proxy_optim
        self.gamma = gamma

    def calc_awp(self, inputs_adv, inputs_clean, targets, beta):
        self.proxy.load_state_dict(self.model.state_dict())
        self.proxy.train()

        loss_nat = F.cross_entropy(self.proxy(inputs_clean), targets)

        loss_adv = F.cross_entropy(self.proxy(inputs_adv), targets)

        loss_robust = F.kl_div(F.log_softmax(self.proxy(inputs_adv), dim=1),
                               F.softmax(self.proxy(inputs_clean), dim=1),
                               reduction='batchmean')
        loss = - 1.0 * (loss_nat + 5.*loss_robust - 3.5*min_variance_loss(self.proxy(inputs_adv), targets))

        self.proxy_optim.zero_grad()
        loss.backward()
        self.proxy_optim.step()

        # the adversary weight perturb
        diff = diff_in_weights(self.model, self.proxy)
        return diff

    def perturb(self, diff):
        add_into_weights(self.model, diff, coeff=1.0 * self.gamma)

    def restore(self, diff):
        add_into_weights(self.model, diff, coeff=-1.0 * self.gamma)



